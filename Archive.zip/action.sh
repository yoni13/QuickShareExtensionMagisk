am start -n com.google.android.mosey/.DebugActivity

