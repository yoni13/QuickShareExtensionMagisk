MODDIR=${0%/*}

LD_LIBRARY_PATH=/system/lib64:/vendor/lib64 $MODDIR/system/vendor/bin/mosey_server

